package com.example.hl2launcher.check

import org.junit.Assert.assertTrue
import org.junit.Test

class ReportFormatterTest {
    @Test fun otherGameMessage() {
        val r = VerifyResult(listOf(CheckIssue(ErrorType.OTHER_GAME, "Portal")), null, null)
        val s = ReportFormatter.format(r)
        assertTrue(s.contains("E02"))
        assertTrue(s.contains("другая игра: Portal"))
    }

    @Test fun successMessage() {
        val s = ReportFormatter.format(VerifyResult(emptyList(), null, "Half-Life 2"))
        assertTrue(s.contains("Проверка пройдена"))
    }

    @Test fun warningDoesNotFail() {
        val r = VerifyResult(listOf(CheckIssue(ErrorType.LICENSE_NOT_FOUND)), null, null)
        assertTrue(r.ok)
        assertTrue(ReportFormatter.format(r).contains("W01"))
    }
}

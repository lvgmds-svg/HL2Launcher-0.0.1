package com.example.hl2launcher.check

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ParsersTest {
    @Test fun gameInfoParsed() {
        val gi = GameInfoParser.parse(FakeSource.GAMEINFO)
        assertEquals("Half-Life 2", gi.title)
        assertEquals(220, gi.appId)
    }

    @Test fun gameInfoWithoutAppId() {
        val gi = GameInfoParser.parse("GameInfo\n{\n game \"Portal\"\n}")
        assertEquals("Portal", gi.title)
        assertNull(gi.appId)
    }

    @Test fun acfParsedAndOwnerMasked() {
        val m = AcfParser.parse(FakeSource.ACF_OK)
        assertEquals("220", m["appid"])
        assertEquals("4", m["stateflags"])
        val lic = LicenseInfo.from(m)
        assertEquals(220, lic.appId)
        assertEquals("7656…000", lic.owner)
    }
}

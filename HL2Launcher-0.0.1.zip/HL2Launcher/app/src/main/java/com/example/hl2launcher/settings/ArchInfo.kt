package com.example.hl2launcher.settings

import android.os.Build

/** Какую разрядность поддерживает телефон (нужно, чтобы выбрать правильный APK движка). */
object ArchInfo {
    fun supports64(): Boolean = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
    fun supports32(): Boolean = Build.SUPPORTED_32_BIT_ABIS.isNotEmpty()
    fun abis(): String = Build.SUPPORTED_ABIS.joinToString(", ")

    fun describe(): String {
        val a = if (supports64()) "да" else "нет"
        val b = if (supports32()) "да" else "нет"
        return "64-бит: $a, 32-бит: $b (${abis()})"
    }
}

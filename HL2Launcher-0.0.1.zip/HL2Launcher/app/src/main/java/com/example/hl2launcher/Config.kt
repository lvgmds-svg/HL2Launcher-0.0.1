package com.example.hl2launcher

object Config {
    // true: если рядом с Half-Life 2 лежат папки других игр (episodic, portal, cstrike…) — ошибка E03.
    // Обычная Steam-копия HL2 часто содержит episodic/ep2/lostcoast; тогда поставь false.
    const val STRICT_OTHER_GAMES = true

    // package name установленного Android-движка Source (порт). Впиши свой.
    const val ENGINE_PACKAGE = "PUT.ENGINE.PACKAGE.HERE"
    // Имя extra, через которое движок получает путь к игре (зависит от порта).
    const val EXTRA_GAMEDIR = "gamedir"
}

package com.example.hl2launcher.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat

/** Экран с кнопками: мультитач, режим редактирования (перетаскивание), скрытие панели. */
class GameControlsView(
    context: Context,
    private val layout: ControlLayout,
    private val sink: InputSink,
    private val onSpecial: (ControlAction) -> Unit
) : View(context) {

    var editMode = false
    var panelVisible = true

    private val pressed = HashMap<Int, ControlAction>()
    private val icons = HashMap<ControlAction, Drawable?>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 4f
    }

    private fun shown(a: ControlAction) =
        editMode || panelVisible || a !in ControlAction.PANEL_GROUP

    private fun icon(a: ControlAction): Drawable? {
        if (!icons.containsKey(a)) {
            val id = resources.getIdentifier("btn_${a.id}", "drawable", context.packageName)
            icons[a] = if (id != 0) ContextCompat.getDrawable(context, id)?.mutate() else null
        }
        return icons[a]
    }

    private fun hit(x: Float, y: Float): ControlAction? {
        for (a in ControlAction.values().reversed()) {
            if (!shown(a)) continue
            val s = layout.map[a] ?: continue
            val r = s.size * height / 2f * 1.1f
            val dx = x - s.x * width
            val dy = y - s.y * height
            if (dx * dx + dy * dy <= r * r) return a
        }
        return null
    }

    private fun down(a: ControlAction) {
        if (a.special) onSpecial(a) else sink.command(a.press)
    }

    private fun up(a: ControlAction) {
        if (a.hold) sink.command("-" + a.press.removePrefix("+"))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val idx = e.actionIndex
        val id = e.getPointerId(idx)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val a = hit(e.getX(idx), e.getY(idx))
                if (a != null) {
                    pressed[id] = a
                    if (!editMode) down(a)
                }
            }
            MotionEvent.ACTION_MOVE -> if (editMode) {
                for (i in 0 until e.pointerCount) {
                    val a = pressed[e.getPointerId(i)] ?: continue
                    layout.move(a, e.getX(i) / width, e.getY(i) / height)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val a = pressed.remove(id)
                if (a != null && !editMode) up(a)
            }
            MotionEvent.ACTION_CANCEL -> {
                if (!editMode) pressed.values.forEach { up(it) }
                pressed.clear()
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        for (a in ControlAction.values()) {
            if (!shown(a)) continue
            val s = layout.map[a] ?: continue
            val cx = s.x * width
            val cy = s.y * height
            val r = s.size * height / 2f
            val on = pressed.containsValue(a)
            val d = icon(a)
            if (d != null) {
                d.setBounds((cx - r).toInt(), (cy - r).toInt(), (cx + r).toInt(), (cy + r).toInt())
                d.alpha = if (on) 255 else 170
                d.draw(c)
            } else {
                paint.alpha = if (on) 255 else 170
                c.drawCircle(cx, cy, r, paint)
                paint.color = Color.BLACK; paint.textSize = r * 0.5f
                c.drawText(a.label.take(4), cx, cy, paint)
                paint.color = Color.WHITE
            }
            if (editMode) c.drawCircle(cx, cy, r, outline)
        }
    }
}

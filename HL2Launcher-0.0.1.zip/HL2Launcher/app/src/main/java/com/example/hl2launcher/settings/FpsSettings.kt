package com.example.hl2launcher.settings

import android.content.Context

/** Ограничение кадров (консольная команда Source fps_max). Шкала: 30 … 120. */
object FpsSettings {
    val STEPS = listOf(30, 45, 60, 90, 120)
    const val DEFAULT = 60
    private const val PREFS = "settings"
    private const val KEY = "fps_max"

    fun nearest(v: Int): Int = STEPS.minByOrNull { Math.abs(it - v) } ?: DEFAULT

    fun load(ctx: Context): Int =
        nearest(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, DEFAULT))

    fun save(ctx: Context, fps: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, nearest(fps)).apply()
    }

    fun cfgLine(fps: Int): String = "fps_max ${nearest(fps)}"
}

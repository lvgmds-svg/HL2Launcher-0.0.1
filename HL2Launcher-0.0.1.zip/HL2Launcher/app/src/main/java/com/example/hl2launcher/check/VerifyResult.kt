package com.example.hl2launcher.check

data class VerifyResult(
    val issues: List<CheckIssue>,
    val license: LicenseInfo?,
    val gameTitle: String?
) {
    val errors: List<CheckIssue> get() = issues.filter { it.type.fatal }
    val warnings: List<CheckIssue> get() = issues.filter { !it.type.fatal }
    val ok: Boolean get() = errors.isEmpty()
}

package com.example.hl2launcher.check

object KnownGames {
    const val HL2_APPID = 220

    val NAMES = mapOf(
        220 to "Half-Life 2", 380 to "Half-Life 2: Episode One", 420 to "Half-Life 2: Episode Two",
        340 to "Half-Life 2: Lost Coast", 320 to "Half-Life 2: Deathmatch",
        400 to "Portal", 620 to "Portal 2", 240 to "Counter-Strike: Source",
        440 to "Team Fortress 2", 4000 to "Garry's Mod",
        70 to "Half-Life", 50 to "Half-Life: Opposing Force", 130 to "Half-Life: Blue Shift",
        280 to "Half-Life: Source", 360 to "Half-Life Deathmatch: Source"
    )

    /** Папки других игр, которые могут лежать рядом с hl2. */
    val OTHER_DIRS = mapOf(
        "episodic" to 380, "ep2" to 420, "lostcoast" to 340, "hl2mp" to 320,
        "portal" to 400, "cstrike" to 240, "tf" to 440, "garrysmod" to 4000,
        "hl1" to 280, "hl1mp" to 360
    )

    fun name(appId: Int): String = NAMES[appId] ?: "AppID $appId"

    fun dirTitle(dir: String): String {
        val id = OTHER_DIRS[dir]
        return if (id != null) name(id) else "папка «$dir»"
    }
}

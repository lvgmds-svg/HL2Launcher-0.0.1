package com.example.hl2launcher.check

/** Простой разбор Steam ACF (KeyValues): берёт пары "ключ" "значение", ключи в нижнем регистре. */
object AcfParser {
    private val PAIR = Regex("\"([^\"]+)\"\\s+\"([^\"]*)\"")

    fun parse(text: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (r in PAIR.findAll(text)) m.putIfAbsent(r.groupValues[1].lowercase(), r.groupValues[2])
        return m
    }
}

package com.example.hl2launcher.check

import java.io.File

class FileGameSource(private val base: File) : GameSource {
    override fun size(path: String): Long {
        val f = File(base, path)
        return if (f.isFile) f.length() else -1L
    }

    override fun head(path: String, n: Int): ByteArray? = try {
        File(base, path).inputStream().use { it.readCapped(n) }
    } catch (e: Exception) { null }

    override fun text(path: String): String? = try {
        val f = File(base, path)
        if (f.isFile) f.inputStream().use { String(it.readCapped(262144), Charsets.UTF_8) } else null
    } catch (e: Exception) { null }

    override fun topDirs(): List<String> =
        base.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()

    override fun totalSize(dirs: List<String>): Long =
        dirs.sumOf { d -> File(base, d).walkTopDown().filter { it.isFile }.sumOf { it.length() } }

    override fun manifestText(): String? {
        var dir: File? = base
        repeat(3) {
            val f = File(dir, "appmanifest_220.acf")
            if (f.isFile) return f.readText()
            dir = dir?.parentFile
        }
        return null
    }
}

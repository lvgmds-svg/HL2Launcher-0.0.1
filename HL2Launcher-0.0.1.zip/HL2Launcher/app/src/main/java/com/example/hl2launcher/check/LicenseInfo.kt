package com.example.hl2launcher.check

/** Данные из манифеста установки Steam (appmanifest_220.acf). Это не доказательство покупки. */
data class LicenseInfo(
    val appId: Int?, val name: String?, val state: Int?,
    val buildId: String?, val sizeOnDisk: Long?, val owner: String?
) {
    fun describe(): String {
        val sb = StringBuilder("AppID ${appId ?: "?"}")
        if (name != null) sb.append(", «").append(name).append("»")
        if (state != null) sb.append(if (state == 4) ", установлена полностью" else ", StateFlags=$state")
        if (buildId != null) sb.append(", build ").append(buildId)
        if (owner != null) sb.append(", владелец ").append(owner)
        return sb.toString()
    }

    companion object {
        fun from(m: Map<String, String>) = LicenseInfo(
            m["appid"]?.toIntOrNull(), m["name"], m["stateflags"]?.toIntOrNull(),
            m["buildid"], m["sizeondisk"]?.toLongOrNull(), m["lastowner"]?.let { mask(it) }
        )

        private fun mask(s: String) = if (s.length <= 7) "***" else s.take(4) + "…" + s.takeLast(3)
    }
}

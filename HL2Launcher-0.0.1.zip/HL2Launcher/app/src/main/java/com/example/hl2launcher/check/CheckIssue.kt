package com.example.hl2launcher.check

data class CheckIssue(val type: ErrorType, val detail: String = "")
